import os
import sys
import json
import tkinter as tk
from tkinter import messagebox
import keyboard
import threading
import webbrowser
import time
from pathlib import Path

EXT_CRED_FILE = "ext_credentials.json"

# -------------------------------------------------------------
# FORCE WINDOW TO FRONT
# -------------------------------------------------------------
def force_window_to_front(window):
    """Aggressively bring window to front on Windows"""
    window.lift()
    window.attributes('-topmost', True)
    window.update()
    window.focus_force()
    
    # Flash the taskbar if available
    if sys.platform == 'win32':
        try:
            import ctypes
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            ctypes.windll.user32.FlashWindow(hwnd, True)
        except:
            pass
    
    # Keep on top briefly then allow normal behavior
    window.after(100, lambda: window.attributes('-topmost', True))
    window.after(200, lambda: window.lift())
    window.after(300, lambda: window.focus_force())

# -------------------------------------------------------------
# AUTO-START ON WINDOWS
# -------------------------------------------------------------
def add_to_startup():
    """Add this program to Windows startup"""
    if sys.platform != 'win32':
        return False
    
    try:
        import winreg
        
        if getattr(sys, 'frozen', False):
            exe_path = sys.executable
        else:
            exe_path = os.path.abspath(__file__)
        
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "LPUWiFiAutoLogin", 0, winreg.REG_SZ, exe_path)
        winreg.CloseKey(key)
        
        return True
    except Exception as e:
        print(f"Failed to add to startup: {e}")
        return False

def is_in_startup():
    """Check if already in startup"""
    if sys.platform != 'win32':
        return False
    
    try:
        import winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_READ)
        try:
            winreg.QueryValueEx(key, "LPUWiFiAutoLogin")
            winreg.CloseKey(key)
            return True
        except FileNotFoundError:
            winreg.CloseKey(key)
            return False
    except:
        return False

# -------------------------------------------------------------
# SYSTEM TRAY ICON
# -------------------------------------------------------------
def create_system_tray():
    """Create system tray icon"""
    try:
        from pystray import Icon, Menu, MenuItem
        from PIL import Image, ImageDraw
        
        def create_icon_image():
            width = 64
            height = 64
            color1 = (33, 150, 243)
            color2 = (255, 255, 255)
            
            image = Image.new('RGB', (width, height), color1)
            dc = ImageDraw.Draw(image)
            
            dc.ellipse([20, 35, 44, 59], fill=color2)
            dc.arc([10, 25, 54, 69], 0, 180, fill=color2, width=4)
            dc.arc([5, 15, 59, 79], 0, 180, fill=color2, width=4)
            
            return image
        
        def on_quit(icon, item):
            icon.stop()
            os._exit(0)
        
        def on_open_settings(icon, item):
            webbrowser.open("https://internet.lpu.in/24online/")
        
        menu = Menu(
            MenuItem("LPU WiFi Auto Login", lambda: None, enabled=False),
            MenuItem("Press Ctrl+Alt+L to login", lambda: None, enabled=False),
            Menu.SEPARATOR,
            MenuItem("Open Login Page", on_open_settings),
            MenuItem("Quit", on_quit)
        )
        
        icon = Icon("LPU WiFi", create_icon_image(), "LPU WiFi Auto Login", menu)
        return icon
    except ImportError:
        return None

# -------------------------------------------------------------
# INSTALLATION INSTRUCTIONS WINDOW - MAXIMUM VISIBILITY
# -------------------------------------------------------------
def show_installation_instructions():
    """Show installation window with MAXIMUM visibility"""
    
    # Create root window FIRST
    root = tk.Tk()
    
    # CRITICAL: Withdraw then deiconify to force new window
    root.withdraw()
    
    root.title("⚠️ LPU WiFi Setup - ACTION REQUIRED")
    root.geometry("650x750")
    root.resizable(False, False)
    
    # Configure window to be always visible
    root.attributes('-topmost', True)
    
    # Center window BEFORE showing
    root.update_idletasks()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width // 2) - 325
    y = (screen_height // 2) - 375
    root.geometry(f'650x750+{x}+{y}')
    
    # Show window NOW
    root.deiconify()
    root.update()
    
    # Force to front multiple times
    root.lift()
    root.focus_force()
    root.attributes('-topmost', True)
    
    # Flash window on Windows
    if sys.platform == 'win32':
        try:
            import ctypes
            # Get window handle
            root.update()
            hwnd = int(root.wm_frame(), 16) if root.wm_frame() else None
            if hwnd:
                # Flash window
                ctypes.windll.user32.FlashWindow(hwnd, True)
                # Set foreground
                ctypes.windll.user32.SetForegroundWindow(hwnd)
        except:
            pass
    
    # ============================================
    # HEADER - BRIGHT WARNING
    # ============================================
    header_frame = tk.Frame(root, bg="#FF5722", height=90)
    header_frame.pack(fill=tk.X)
    header_frame.pack_propagate(False)
    
    tk.Label(header_frame, text="⚠️ SETUP REQUIRED ⚠️", 
            font=("Arial", 24, "bold"), fg="white", bg="#FF5722").pack(pady=30)
    
    # ============================================
    # MAIN CONTENT
    # ============================================
    main_frame = tk.Frame(root, bg="white")
    main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)
    
    tk.Label(main_frame, text="LPU WiFi Auto Login - First Time Installation", 
            font=("Arial", 13, "bold"), bg="white", fg="#333").pack(pady=10)
    
    # ============================================
    # INSTRUCTIONS BOX
    # ============================================
    inst_frame = tk.Frame(main_frame, bg="#FFF3E0", relief=tk.SOLID, bd=3, highlightbackground="#FF9800", highlightthickness=2)
    inst_frame.pack(pady=10, padx=5, fill=tk.BOTH, expand=True)
    
    instructions = """
🔧 CHROME EXTENSION SETUP (MANDATORY!)

⚠️ Without this, the app WILL NOT WORK! ⚠️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STEP 1: Open Google Chrome

STEP 2: Copy & paste this in address bar:
        chrome://extensions/
        (Then press Enter)

STEP 3: Enable "Developer mode"
        → Look at TOP-RIGHT corner
        → Turn ON the toggle switch

STEP 4: Click "Load unpacked" button
        (Appears after enabling Developer mode)

STEP 5: Select the 'extension' folder
        Location: Same folder where the .exe is
        
STEP 6: Extension installed! ✅

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 AFTER INSTALLING EXTENSION:

1. Click extension icon in Chrome toolbar
2. Enter your LPU User ID (8 digits)
3. Enter your password
4. Click "Save Credentials"
5. Done! Extension works ONLY on WiFi page

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⌨️ HOW TO USE:

• Connect to LPU WiFi
• Press: Ctrl + Alt + L (anywhere, anytime)
• Chrome opens → Auto-login happens!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🟢 BACKGROUND SERVICE:

✅ Added to Windows startup
✅ Runs silently in system tray  
✅ Always listening for Ctrl+Alt+L
    """
    
    text_widget = tk.Text(inst_frame, font=("Consolas", 10), 
                         bg="#FFF3E0", fg="#212121",
                         wrap=tk.WORD, padx=15, pady=15,
                         height=28, borderwidth=0)
    text_widget.insert("1.0", instructions)
    text_widget.config(state=tk.DISABLED)  # Read-only
    text_widget.pack(fill=tk.BOTH, expand=True)
    
    # ============================================
    # HELPER BUTTONS
    # ============================================
    button_frame = tk.Frame(main_frame, bg="white")
    button_frame.pack(pady=15)
    
    def open_extension_folder():
        """Open the extension folder"""
        if getattr(sys, 'frozen', False):
            exe_dir = os.path.dirname(sys.executable)
        else:
            exe_dir = os.path.dirname(os.path.abspath(__file__))
        
        ext_folder = os.path.join(exe_dir, 'extension')
        
        if os.path.exists(ext_folder):
            if sys.platform == 'win32':
                os.startfile(ext_folder)
                messagebox.showinfo(
                    "Folder Opened ✅", 
                    "The 'extension' folder is now open!\n\n"
                    "Next steps:\n"
                    "1. Go to Chrome\n"
                    "2. Open chrome://extensions/\n"
                    "3. Enable Developer mode\n"
                    "4. Click 'Load unpacked'\n"
                    "5. Select the opened folder",
                    parent=root
                )
            else:
                webbrowser.open(f'file://{ext_folder}')
        else:
            messagebox.showerror(
                "Error", 
                f"❌ Extension folder NOT found!\n\n"
                f"Expected: {ext_folder}\n\n"
                "Make sure 'extension' folder is in the same\n"
                "directory as the .exe file!",
                parent=root
            )
    
    def copy_chrome_url():
        """Copy chrome://extensions/ to clipboard"""
        root.clipboard_clear()
        root.clipboard_append("chrome://extensions/")
        root.update()
        messagebox.showinfo(
            "Copied! ✅", 
            "chrome://extensions/\n\n"
            "✅ Copied to clipboard!\n\n"
            "Now paste it in Chrome address bar.",
            parent=root
        )
    
    # Button row 1
    btn_row1 = tk.Frame(button_frame, bg="white")
    btn_row1.pack(pady=3)
    
    tk.Button(btn_row1, text="📂 Open Extension Folder", 
             command=open_extension_folder,
             bg="#2196F3", fg="white", 
             font=("Arial", 11, "bold"),
             width=28, height=2).pack(side=tk.LEFT, padx=5)
    
    tk.Button(btn_row1, text="📋 Copy Chrome URL", 
             command=copy_chrome_url,
             bg="#9C27B0", fg="white", 
             font=("Arial", 11, "bold"),
             width=28, height=2).pack(side=tk.LEFT, padx=5)
    
    # Button row 2 - Main action button
    def finish_setup():
        # Remove topmost to show dialog properly
        root.attributes('-topmost', False)
        
        result = messagebox.askyesno(
            "Confirm Setup Complete", 
            "⚠️ Have you completed ALL these steps?\n\n"
            "✅ Opened Chrome\n"
            "✅ Went to chrome://extensions/\n"
            "✅ Enabled Developer mode\n"
            "✅ Clicked 'Load unpacked'\n"
            "✅ Selected 'extension' folder\n"
            "✅ Extension is now installed\n"
            "✅ Entered credentials in extension\n\n"
            "Click YES to start the app.",
            parent=root
        )
        
        if result:
            root.destroy()
        else:
            # Put back on top if they said no
            root.attributes('-topmost', True)
            root.lift()
    
    tk.Button(button_frame, text="✅ I've Completed Setup - Start App!", 
             command=finish_setup,
             bg="#4CAF50", fg="white", 
             font=("Arial", 13, "bold"),
             width=45, height=2).pack(pady=10)
    
    # ============================================
    # FOOTER WARNING
    # ============================================
    tk.Label(main_frame, 
            text="⚠️ Extension ONLY works on: internet.lpu.in/24online/\n"
                 "Press Ctrl+Alt+L after setup to test!", 
            font=("Arial", 9, "bold"), bg="white", fg="#d32f2f").pack(pady=8)
    
    # ============================================
    # KEEP WINDOW VISIBLE
    # ============================================
    def keep_on_top():
        """Keep window on top for first 10 seconds"""
        for i in range(10):
            root.after(i * 1000, lambda: root.lift())
            root.after(i * 1000, lambda: root.attributes('-topmost', True))
    
    keep_on_top()
    
    # After 10 seconds, allow user to move it behind
    def allow_behind():
        root.attributes('-topmost', False)
    
    root.after(10000, allow_behind)
    
    # Force window to front one more time
    force_window_to_front(root)
    
    # Start the GUI loop
    root.mainloop()

# -------------------------------------------------------------
# MAIN APPLICATION CLASS
# -------------------------------------------------------------
class LPUWiFiApp:
    def __init__(self):
        self.config_file = self.get_config_path()
        self.credentials = None

        # Try loading credentials
        ext_creds = self.load_from_extension()
        if ext_creds:
            self.credentials = ext_creds
            self.save_credentials(ext_creds["username"], ext_creds["password"])
            print("\n✔ Loaded credentials from Chrome extension")
        else:
            self.credentials = self.load_credentials()
            if self.credentials:
                print("\n✔ Loaded credentials from local storage")

        if not self.credentials:
            print("\n⚠️ No credentials found - showing setup window")
            self.show_setup_window()
        else:
            self.start_hotkey_listener()

    def get_config_path(self):
        """Get config file path"""
        if sys.platform == 'win32':
            app_data = os.getenv('APPDATA')
            config_dir = os.path.join(app_data, 'LPUWiFiAutoLogin')
        else:
            home = str(Path.home())
            config_dir = os.path.join(home, '.lpuwifi')

        os.makedirs(config_dir, exist_ok=True)
        return os.path.join(config_dir, 'credentials.json')

    def load_credentials(self):
        """Load stored credentials"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    return json.load(f)
        except Exception as e:
            print("Error loading credentials:", e)
        return None

    def load_from_extension(self):
        """Load credentials from extension shared file"""
        config_dir = os.path.dirname(self.config_file)
        ext_file = os.path.join(config_dir, EXT_CRED_FILE)

        if os.path.exists(ext_file):
            try:
                with open(ext_file, "r") as f:
                    data = json.load(f)
                if "username" in data and "password" in data:
                    return data
            except:
                return None
        return None

    def save_credentials(self, username, password):
        """Save credentials locally"""
        try:
            creds = {"username": username, "password": password}
            with open(self.config_file, "w") as f:
                json.dump(creds, f)

            if sys.platform != 'win32':
                os.chmod(self.config_file, 0o600)

            self.credentials = creds
            return True
        except Exception as e:
            print("Error saving credentials:", e)
            return False

    def show_setup_window(self):
        """Show setup window for manual credential entry"""
        self.setup_window = tk.Tk()
        
        # Withdraw and deiconify trick
        self.setup_window.withdraw()
        
        self.setup_window.title("LPU WiFi - Enter Credentials")
        self.setup_window.geometry("500x600")
        self.setup_window.resizable(False, False)
        
        # Center window
        self.setup_window.update_idletasks()
        x = (self.setup_window.winfo_screenwidth() // 2) - 250
        y = (self.setup_window.winfo_screenheight() // 2) - 300
        self.setup_window.geometry(f'500x600+{x}+{y}')
        
        # Show and force to front
        self.setup_window.deiconify()
        self.setup_window.attributes('-topmost', True)
        self.setup_window.lift()
        self.setup_window.focus_force()

        # Header
        header_frame = tk.Frame(self.setup_window, bg="#1a73e8", height=80)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="LPU WiFi Auto Login", 
                font=("Arial", 18, "bold"), fg="white", bg="#1a73e8").pack(pady=25)
        
        content_frame = tk.Frame(self.setup_window, bg="white")
        content_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        tk.Label(content_frame, text="Credential Setup (Optional)", 
                font=("Arial", 14, "bold"), bg="white").pack(pady=10)

        instructions = (
            "🔧 Recommended: Use Chrome Extension\n\n"
            "The extension is more secure and convenient.\n"
            "It auto-fills credentials ONLY on WiFi page.\n\n"
            "OR enter credentials here manually:"
        )
        
        inst_label = tk.Label(content_frame, text=instructions, 
                font=("Arial", 10), justify="left", fg="#555", bg="white")
        inst_label.pack(pady=15)

        # Form
        form_frame = tk.Frame(content_frame, bg="#f5f5f5", relief=tk.RAISED, bd=2)
        form_frame.pack(pady=20, padx=20, fill=tk.X)
        
        tk.Label(form_frame, text="User ID (8 digits only):", 
                font=("Arial", 11, "bold"), bg="#f5f5f5").pack(pady=(20, 5))
        self.username_entry = tk.Entry(form_frame, width=25, font=("Arial", 13))
        self.username_entry.pack(pady=5)

        tk.Label(form_frame, text="Password:", 
                font=("Arial", 11, "bold"), bg="#f5f5f5").pack(pady=(15, 5))
        self.password_entry = tk.Entry(form_frame, width=25, 
                                      font=("Arial", 13), show="•")
        self.password_entry.pack(pady=(5, 20))

        # Buttons
        btn_frame = tk.Frame(content_frame, bg="white")
        btn_frame.pack(pady=20)
        
        tk.Button(btn_frame, text="💾 Save & Start App", 
                 command=self.manual_save,
                 bg="#4CAF50", fg="white", 
                 font=("Arial", 12, "bold"),
                 width=25, height=2).pack(pady=5)
        
        tk.Button(btn_frame, text="⏭️ Skip - I'll Use Extension", 
                 command=self.skip_setup,
                 bg="#757575", fg="white", 
                 font=("Arial", 10),
                 width=25, height=1).pack(pady=5)
        
        # Keep on top for a few seconds
        force_window_to_front(self.setup_window)
        self.setup_window.after(5000, lambda: self.setup_window.attributes('-topmost', False))
        
        self.setup_window.mainloop()

    def manual_save(self):
        """Manual save credentials"""
        u = self.username_entry.get().strip()
        p = self.password_entry.get().strip()

        u = ''.join(filter(str.isdigit, u))[:8]

        if len(u) != 8:
            messagebox.showwarning("Invalid Input", 
                                  "User ID must be exactly 8 digits!",
                                  parent=self.setup_window)
            return

        if not p:
            messagebox.showwarning("Missing Password", 
                                  "Password cannot be empty!",
                                  parent=self.setup_window)
            return

        if self.save_credentials(u, p):
            messagebox.showinfo("Success", 
                               "✅ Credentials saved!\n\n"
                               "Press Ctrl+Alt+L anytime to auto-login!",
                               parent=self.setup_window)
            self.setup_window.destroy()
            self.start_hotkey_listener()
        else:
            messagebox.showerror("Error", 
                                "Failed to save credentials!",
                                parent=self.setup_window)

    def skip_setup(self):
        """Skip manual setup"""
        self.setup_window.attributes('-topmost', False)
        
        result = messagebox.askyesno(
            "Skip Manual Entry", 
            "Skip entering credentials here?\n\n"
            "Make sure you've:\n"
            "✅ Installed Chrome Extension\n"
            "✅ Entered credentials in extension popup\n\n"
            "App will check for extension credentials.",
            parent=self.setup_window
        )
        
        if result:
            self.setup_window.destroy()
            self.start_hotkey_listener_without_creds()

    def start_hotkey_listener(self):
        """Start hotkey listener with credentials"""
        print("\n" + "=" * 60)
        print("🚀 LPU WiFi Auto Login is ACTIVE!")
        print("=" * 60)
        print("✔ Credentials loaded")
        print(f"✔ User ID: {self.credentials['username']}")
        print("⌨️  Press Ctrl + Alt + L ANYTIME to auto-login")
        print("=" * 60)
        print("\n💡 Running in background (system tray)\n")

        keyboard.add_hotkey("ctrl+alt+l", self.trigger_login)

        tray_icon = create_system_tray()
        
        if tray_icon:
            print("✔ System tray icon active\n")
            tray_icon.run()
        else:
            try:
                keyboard.wait()
            except KeyboardInterrupt:
                print("\nExiting...")
                sys.exit(0)

    def start_hotkey_listener_without_creds(self):
        """Start listener without credentials - wait for extension"""
        print("\n" + "=" * 60)
        print("⏳ Waiting for credentials from extension...")
        print("=" * 60)
        print("⚠️  No credentials found yet")
        print("🔧 Please enter credentials in Chrome Extension")
        print("🔄 Checking every 10 seconds...")
        print("=" * 60 + "\n")

        def check_credentials_periodically():
            while True:
                time.sleep(10)
                ext_creds = self.load_from_extension()
                if ext_creds:
                    self.credentials = ext_creds
                    self.save_credentials(ext_creds["username"], ext_creds["password"])
                    print("\n✅ Credentials found from extension!")
                    print(f"   User ID: {ext_creds['username']}")
                    print("   Hotkey now active!\n")
                    break
        
        checker_thread = threading.Thread(target=check_credentials_periodically, daemon=True)
        checker_thread.start()

        keyboard.add_hotkey("ctrl+alt+l", self.trigger_login)

        tray_icon = create_system_tray()
        
        if tray_icon:
            print("✔ Running in system tray\n")
            tray_icon.run()
        else:
            try:
                keyboard.wait()
            except KeyboardInterrupt:
                print("\nExiting...")
                sys.exit(0)

    def trigger_login(self):
        """Trigger login when hotkey pressed"""
        if not self.credentials:
            print("\n⚠️  No credentials! Please set up Chrome Extension")
            return

        print("\n" + "=" * 60)
        print("🔓 HOTKEY PRESSED - AUTO LOGIN!")
        print("=" * 60)
        print(f"👤 User: {self.credentials['username']}")
        print("🌐 Opening LPU WiFi login page...")
        print("=" * 60)
        
        # Open WiFi login page - extension will auto-fill
        webbrowser.open("https://internet.lpu.in/24online/")
        
        print("\n✅ Browser opened!")
        print("   Extension will auto-login (only on WiFi page)\n")

# -------------------------------------------------------------
# ENTRY POINT
# -------------------------------------------------------------
if __name__ == "__main__":
    # Ensure we're not running as a background process
    print("=" * 60)
    print("🚀 LPU WiFi Auto Login - Starting...")
    print("=" * 60)
    
    config_dir = os.path.join(os.getenv('APPDATA') if sys.platform == 'win32' 
                              else str(Path.home()), 
                              'LPUWiFiAutoLogin' if sys.platform == 'win32' else '.lpuwifi')
    os.makedirs(config_dir, exist_ok=True)
    
    first_run_marker = os.path.join(config_dir, '.first_run_complete')
    
    # First run detection
    if not os.path.exists(first_run_marker):
        print("\n🎉 FIRST RUN DETECTED!")
        print("📋 Showing installation instructions...\n")
        
        # Add to Windows startup
        if sys.platform == 'win32':
            if add_to_startup():
                print("✅ Added to Windows Startup")
            else:
                print("⚠️ Could not add to startup")
        
        # SHOW INSTALLATION UI - This is the critical part
        print("🪟 Opening installation window...\n")
        show_installation_instructions()
        
        # Mark first run as complete AFTER user closes the window
        print("✅ Installation window closed by user")
        open(first_run_marker, 'w').close()
        print("✅ First-time setup marked complete!\n")
    else:
        print("\n✔ Not first run - loading normally...")
        # Ensure still in startup
        if sys.platform == 'win32' and not is_in_startup():
            print("⚠️ Re-adding to Windows startup...")
            add_to_startup()
    
    print("\n🔍 Initializing application...\n")
    app = LPUWiFiApp()